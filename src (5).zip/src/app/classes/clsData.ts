import { tableCodeDesc } from "./tableCodeDesc";

export class clsData {
    

    constructor(public merchavim?: Array<tableCodeDesc>,
        public ezorim?: Array<tableCodeDesc>,
        public yeshuvim?: Array<tableCodeDesc>)
         {
        merchavim = new Array<tableCodeDesc>();
        ezorim = new Array<tableCodeDesc>();
        yeshuvim = new Array<tableCodeDesc>();
         }
         
    // merchavim: Array<tableCodeDesc> = new Array<tableCodeDesc>();
    // yeshuvim: Array<tableCodeDesc> = new Array<tableCodeDesc>();
    // ezorim: Array<tableCodeDesc> = new Array<tableCodeDesc>();
  
    //   constructor(merchavim: Array<tableCodeDesc>,yeshuvim: Array<tableCodeDesc>,ezorim: Array<tableCodeDesc>) {
    //     this.merchavim = merchavim;
    //     this.yeshuvim = yeshuvim; 
    //     this.ezorim = ezorim; 
    //   }
  }


