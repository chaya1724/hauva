export class tableCodeDesc {
    
    code: number;
    desc: string;
  
      constructor(m_code: number,m_desc: string) {
        this.code = m_code;
        this.desc = m_desc; 
      }
  }