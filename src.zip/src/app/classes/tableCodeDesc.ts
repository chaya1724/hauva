export class tableCodeDesc {
    
    m_code: number;
    m_desc: string;
  
      constructor(m_code: number,m_desc: string) {
        this.m_code = m_code;
        this.m_desc = m_desc; 
      }
  }